"""Recompute the incremental source-review audit using only the standard library."""
import argparse
import hashlib
import json
from pathlib import Path


def summarize(base):
    manifest = json.loads((base / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in manifest.items():
        if Path(name).name != name:
            raise ValueError('Manifest members must be local filenames')
        if hashlib.sha256((base / name).read_bytes()).hexdigest() != expected:
            raise ValueError('Hash mismatch: ' + name)
    load = lambda name: json.loads((base / name).read_text(encoding='utf-8'))
    rows = load('cases-300.json')
    original = {row['id']:row for row in load('300-summary.json')['per_question']}
    criteria = {row['id']:row for row in load('300-dataset.json')['questions']}
    assert len(rows) == len({r['id'] for r in rows}) == 300
    assert {r['id'] for r in rows} == set(original) == set(criteria)
    def validate(row, version):
        item = row[version]
        assert item['answer_sha256'] == hashlib.sha256(item['answer'].encode('utf-8')).hexdigest()
        if item['method'] == 'reused_archived_both_round_label':
            assert item['answer'] == row['original']['answer']
            assert item['pass_value'] == original[row['id']]['both_pass']['new']
        elif 'review' in item:
            score = item['review']
            assert len(score['points']) == len(row['review_points'])
            assert all(type(v) is bool for v in score['points'] + [score['supported'],score['boundary']])
            assert item['pass_value'] == (all(score['points']) and score['supported'] and score['boundary'])
        else:
            assert item['method'] == 'coding_assistant_source_review'
            assert len(item['points']) == len(row['required_points'])
            assert all(type(v) is bool for v in item['points'] + [item['supported'],item['boundary']])
            assert item['pass_value'] == (all(item['points']) and item['supported'] and item['boundary'] and row['original']['finish_stop'])
    for row in rows:
        assert row['required_points'] == criteria[row['id']]['required_points']
        assert row['original']['pass'] == original[row['id']]['both_pass']['new']
        for version in ['pre','post']:
            validate(row,version)
    def tally(selected):
        pre = sum(row['pre']['pass_value'] for row in selected)
        post = sum(row['post']['pass_value'] for row in selected)
        n = len(selected)
        return {'n':n,'pre_pass':pre,'post_pass':post,'pre_percent':round(100*pre/n,4),
                'post_percent':round(100*post/n,4),'delta_pp':round(100*(post-pre)/n,4),
                'wins':[row['id'] for row in selected if not row['pre']['pass_value'] and row['post']['pass_value']],
                'losses':[row['id'] for row in selected if row['pre']['pass_value'] and not row['post']['pass_value']]}
    rows20 = load('cases-20.json')
    original20 = {row['id']:row for row in load('20-review.json')['per_question']}
    assert len(rows20) == len({(r['id'],r['arm']) for r in rows20}) == 40
    for row in rows20:
        assert row['review_points'] == original20[row['id']]['review_points']
        for version in ['pre','post']:
            validate(row,version)
            if row[version]['method'].startswith('reused_'):
                assert row[version]['answer'] == row['original']['answer']
                assert row[version]['review'] == original20[row['id']][row['arm']]['visible']
    result = {'date':'2026-11-24','runtime_pre':'295405e','runtime_post':'7b14975',
              'method':'Incremental audit: 300 unchanged labels retain archived two-round intersection, affected labels use single coding-assistant source review; 20 retains frozen same-assistant point criteria. Not a new full model judging run.',
              'paid_calls':0,'reviewed_union_300':[r['id'] for r in rows if r['pre']['method']=='coding_assistant_source_review'],
              'latest_changed_300':[r['id'] for r in rows if r['pre']['answer']!=r['post']['answer']],
              'incremental_300':tally(rows),
              'reviewed_union_subset':tally([r for r in rows if r['pre']['method']=='coding_assistant_source_review']),
              'default_prompt_20':tally([r for r in rows20 if r['arm']=='baseline']),
              'archived_experimental_prompt_20':tally([r for r in rows20 if r['arm']=='optimized'])}
    assert result['latest_changed_300'] == ['b099','b220']
    assert len(result['reviewed_union_300']) == 10
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output',type=Path)
    args = parser.parse_args()
    result = summarize(Path(__file__).resolve().parent)
    if args.output:
        with args.output.open('x',encoding='utf-8') as handle:
            json.dump(result,handle,ensure_ascii=False,indent=2)
            handle.write('\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
