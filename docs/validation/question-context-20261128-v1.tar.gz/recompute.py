import json,runpy,hashlib,socket
from pathlib import Path
p=Path(__file__).resolve().parent
for n,h in json.loads((p/'manifest.json').read_text()).items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h
socket.socket.connect=lambda *a,**k:(_ for _ in ()).throw(AssertionError('No network'))
b=runpy.run_path(str(p/'before.py'))['render_context_answer'];a=runpy.run_path(str(p/'after.py'))['render_context_answer']
r=json.loads((p/'summary.json').read_text(encoding='utf-8'));changes=[]
for c in json.loads((p/'cases300.json').read_text(encoding='utf-8')):
 assert b(c['raw'],c['sources'],c['question'],extractive_quotes=True)==c['before']
 assert a(c['raw'],c['sources'],c['question'],extractive_quotes=True)==c['after']
 if c['before']!=c['after']:changes.append(c['id'])
 if c['risk']:assert c['before']==c['after']
assert changes==r['changed_ids']
for c in json.loads((p/'independent.json').read_text(encoding='utf-8')):
 if not c['guarded']:
  for mode in [False,True]:assert b(c['raw'],c['sources'],c['question'],extractive_quotes=mode)==a(c['raw'],c['sources'],c['question'],extractive_quotes=mode)
assert sum(x['before_pass'] for x in r['review'])==5 and sum(x['after_pass'] for x in r['review'])==7
print(json.dumps({k:v for k,v in r.items() if k!='review'},ensure_ascii=False))
