import pytest
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.documents import Document
from langchain_core.runnables import RunnableLambda
from src.services.answer_policy import SAFETY_ANSWER, UNSUPPORTED_ANSWER
from src.services.direct_answer import render_direct_answer
from src.services.prompts import DIRECT_CONTEXT_SYSTEM_PROMPT, CONTEXT_SYSTEM_PROMPT
from src.services.rag import RagService

SOURCES = [{"id":"S1","excerpt":"按资料清洁滤网。"}]

@pytest.mark.parametrize('raw',[
    '电池长时间不用，拆卸存放。[S1]',
    '把电池取出，之后联系售后。[S1]',
    '给轴承滴润滑油，之后联系售后。[S1]',
    '关闭碰撞保护再重启。[S1]',
])
def test_direct_rejects_dangerous_operation_even_with_later_warning(raw):
    assert render_direct_answer(raw,SOURCES,'怎么操作？') == SAFETY_ANSWER

@pytest.mark.parametrize('raw',[
    '按资料清洁滤网。[S1]',
    '不要拆卸电池，联系售后。[S1]',
    '当前知识库不足以确认。',
    '请提供具体型号？',
])
def test_direct_keeps_evidenced_cleaning_prohibitions_and_clarifications(raw):
    assert render_direct_answer(raw,SOURCES,'咨询') == raw

def test_direct_does_not_invent_source_ids():
    assert render_direct_answer('明确结论[S99]',SOURCES,'功能？') == UNSUPPORTED_ANSWER

def test_direct_adds_active_electrical_risk_boundary():
    answer=render_direct_answer('可能是堵塞。[S1]',SOURCES,'外壳烫手有怪味')
    assert answer.startswith('请先停止使用和充电')

def test_actual_rag_direct_messages_sources_and_history_agree():
    history=InMemoryChatMessageHistory();captured=[]
    class Retriever:
        def invoke(self,query):
            return [Document(page_content='滤网应晾干后使用。',metadata={'source':'资料.txt'})]
    def model(prompt):
        captured.extend(prompt.to_messages())
        return '滤网应晾干后使用。[S1]'
    service=RagService(Retriever(),RunnableLambda(model),lambda _:history,
                       context_entries_enabled=True,context_answer_format='direct')
    events=list(service.stream_answer('滤网如何使用？','direct'))
    answer=''.join(e.get('content','') for e in events)
    assert answer=='滤网应晾干后使用。[S1]'
    assert history.messages[-1].content==answer
    assert captured[0].content==DIRECT_CONTEXT_SYSTEM_PROMPT
    assert events[0]['sources'][0]['excerpt']=='滤网应晾干后使用。'

def test_quoted_mode_remains_default_and_bad_mode_is_rejected():
    service=RagService(object(),RunnableLambda(lambda _:''),context_entries_enabled=True)
    assert service.context_answer_format=='quoted' and service.context_system_prompt==CONTEXT_SYSTEM_PROMPT
    with pytest.raises(ValueError):
        RagService(object(),RunnableLambda(lambda _:''),context_answer_format='typo')
