"""Direct-answer experiment using frozen references and existing safety rules."""
import re
from .answer_policy import finalize_answer, operation_boundary, SAFETY_ANSWER

def render_direct_answer(raw, sources, question):
    # Carry a battery subject across clauses, without treating a later warning
    # as permission to remove it. This experiment does not alter quoted mode.
    for sentence in re.split(r'[。！？\n]',raw):
        battery=False
        for clause in re.split(r'[，,；;]',sentence):
            battery=battery or '电池' in clause
            if battery:
                action=re.search(r'拆卸|拆下|取出|拔出|拔下|插拔|重新连接',clause)
                if action and not re.search(r'不要|不可|不得|不能|不建议|请勿|切勿|禁止|专业售后|专业人员',clause[:action.start()]):
                    raw=SAFETY_ANSWER
                    break
    answer=finalize_answer(raw,{s['id'] for s in sources}) if raw!=SAFETY_ANSWER else raw
    boundary=operation_boundary(question)
    return boundary+'\n\n'+answer if boundary and boundary not in answer else answer
