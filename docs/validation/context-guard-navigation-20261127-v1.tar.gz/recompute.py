import hashlib,json,runpy,socket
from pathlib import Path
root=Path(__file__).resolve().parent
for name,sha in json.loads((root/'artifact-manifest.json').read_text()).items():
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
socket.socket.connect=lambda *a,**k:(_ for _ in ()).throw(AssertionError('No network'))
before=runpy.run_path(str(root/'before_policy.py'))['render_context_answer']
after=runpy.run_path(str(root/'after_policy.py'))['render_context_answer']
for c in json.loads((root/'changes.json').read_text(encoding='utf-8')):
    assert before(c['raw'],c['sources'],c['question'])==c['before']
    assert after(c['raw'],c['sources'],c['question'])==c['after']
for c in json.loads((root/'cases70.json').read_text(encoding='utf-8')):
    if not c['guarded']:
        assert before(c['raw'],c['sources'],c['question'])==c['after']
        assert after(c['raw'],c['sources'],c['question'])==c['after']
direct=runpy.run_path(str(root/'summarize_direct.py'))['summarize'](root/'direct-run')
summary=json.loads((root/'summary.json').read_text(encoding='utf-8'))
assert {k:v for k,v in direct.items() if k not in ['budget','per_question']}==summary['rejected_direct']
print(json.dumps({k:v for k,v in summary.items() if k!='changes'},ensure_ascii=False))
