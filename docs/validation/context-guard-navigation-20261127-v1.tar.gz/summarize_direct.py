import json
from decimal import Decimal
from pathlib import Path
import sys

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def summarize(root):
    data=read(root/'inputs.json');rounds=[];rows=[]
    for k in range(2):
        valid=[]
        for row in data['rows']:
            i=row['q']['id'];path=root/'outputs'/f'{i}-judge{k}.json'
            if not path.exists():continue
            score=read(path)
            valid.append({'id':i,'risk':row['q']['safety_expected'],
                          'pass':{a:score['scores'][a]['correct'] and score['scores'][a]['supported'] for a in ['baseline','candidate']}})
        rounds.append({'valid_pairs':len(valid),'pass':{a:sum(x['pass'][a] for x in valid) for a in ['baseline','candidate']},
                       'risk_pairs':sum(x['risk'] for x in valid),'risk_pass':{a:sum(x['pass'][a] for x in valid if x['risk']) for a in ['baseline','candidate']}})
    usage={m:{'calls':0,'input_tokens':0,'output_tokens':0} for m in ['qwen-plus','qwen-max']}
    for p in (root/'outputs').glob('*.json'):
        if p.name.endswith('-generation.json') or p.name.endswith('-raw.json'):
            model='qwen-plus' if p.name.endswith('-generation.json') else 'qwen-max';value=read(p)
            usage[model]['calls']+=1
            for key in ['input_tokens','output_tokens']:usage[model][key]+=value['usage'][key]
    for row in data['rows']:
        i=row['q']['id'];raw=read(root/'outputs'/f'{i}-generation.json')
        rows.append({'id':i,'question':row['q']['query'],'risk':row['q']['safety_expected'],'baseline':row['baseline'],
                     'candidate':read(root/'outputs'/f'{i}-answer.json')['answer'],'finish_reason':raw['finish_reason']})
    cost=sum(Decimal(usage[m]['input_tokens'])*Decimal(a)+Decimal(usage[m]['output_tokens'])*Decimal(b)
             for m,a,b in [('qwen-plus','.8','2'),('qwen-max','2.4','9.6')])/1000000
    return {'status':'rejected; paired second round incomplete','questions':20,'rounds':rounds,'usage':usage,
            'estimated_token_cost_cny':str(cost),'budget':read(root/'budget.json.usage.json'),
            'failure':read(root/'failure.json'),'per_question':rows}
if __name__=='__main__':
    s=summarize(Path(sys.argv[1]));print(json.dumps({k:v for k,v in s.items() if k not in ['budget','per_question']},ensure_ascii=False,indent=2))
