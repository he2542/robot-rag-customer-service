import json,hashlib
from pathlib import Path
from codex_client import fingerprint,parse_events
base=Path(__file__).resolve().parent
def read(name):return json.loads((base/name).read_text(encoding="utf-8"))
for name,digest in read("manifest.json").items():
    assert not Path(name).is_absolute() and ".." not in Path(name).parts
    assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest,name
frozen=read("frozen-inputs.json");protocol=read("codex-protocol.json");summary=read("quality-summary.json")
assert fingerprint(frozen)==protocol["frozen_sha256"]==summary["frozen_sha256"]
assert hashlib.sha256((base/"codex_validation.py").read_bytes()).hexdigest()==frozen["runner_sha256"]
assert hashlib.sha256((base/"answer_policy.py").read_bytes()).hexdigest()==frozen["policy_sha256"]
rows=[]
for stage in ("generate","judge"):
    for path in (base/stage).glob("*.json"):
        row=read(path.relative_to(base)); assert Path(row["cache_file"]).name==row["cache_file"]
        result=read("cache/"+row["cache_file"])
        assert fingerprint(result)==row["result_sha256"]
        assert fingerprint(result["binding"])+".json"==row["cache_file"]
        assert result["binding"]["identity"]==protocol["identity"]
        parsed=parse_events("\n".join(json.dumps(e) for e in result["events"]))
        assert parsed["text"]==result["text"] and parsed["usage"]==result["usage"]
        rows.append((stage,result))
assert sum(s=="generate" for s,r in rows)==12
assert sum(s=="judge" for s,r in rows)==5
ledger=read("subscription-ledger.json");a=ledger["attempts"]
assert ledger["stopped"] and len(a)==10 and sum(x["status"]=="success" for x in a)==9
assert sum(x["input_bytes"] for x in a)==summary["input_bytes_reserved"]<=655360
assert all(x["input_bytes"]<=16384 for x in a)
keys={x["cache_key"] for x in a if x["status"]=="success"}
fresh=[r for s,r in rows if fingerprint(r["binding"]) in keys]; assert len(fresh)==9
for k in ("input_tokens","output_tokens"):assert sum(r["usage"][k] for r in fresh)==summary["known_new_usage"][k]
assert summary["quality_comparison"] is None and summary["aliyun_requests"]==0
print(json.dumps({"generated":12,"new_generation":9,"reused_generation":3,"new_subscription_attempts":10,"failed":1,"quality_comparison":None}))
