# Context-message boundary: 20-question paired diagnostic

This package contains the frozen questions, corpus, both application prompt bundles,
exact model messages, forty generated answers, two blinded judge rounds, usage,
timing, and an offline aggregator. No API credentials or conversation histories are
included. `artifact-manifest.json` records SHA-256 for every other packaged file.

The primary automatic pass is `correct && supported`. The raw results are retained
without overrides. `qualitative-review.json` identifies the b022 false positive and
the continued b148/b090 risk advice. Citation aggregation requires an actual valid
bracketed marker as well as the judge's support flag; raw flags are also retained.

## Offline reproduction

No model calls or third-party packages are needed to recalculate the summary:

```bash
python summarize.py --output reproduced-summary.json
python -c "import json; assert json.load(open('reproduced-summary.json', encoding='utf-8')) == json.load(open('summary.json', encoding='utf-8'))"
```

Question and input fingerprints are in `protocol.json`, `inputs-manifest.json` and
`messages-manifest.json`. Every judgment records the hashes of its two answers.

## Paid rerun

Use the project's backend dependencies; `dependencies.json` records the versions
used for this run. Set `DASHSCOPE_API_KEY` in the process environment. Reuse the
frozen inputs and archive the existing `answers`, `judgments`, and `judge_swapped`
directories before starting a new run. Existing successful checkpoints are skipped.
Run from this extracted package directory:

```bash
python runner.py validate
python runner.py answer
python runner.py judge
python runner.py audit
python summarize.py --output rerun-summary.json
```

`runner.py` injects frozen documents and separate empty in-memory histories into
the two actual `RagService` versions. It never retrieves from or writes to a database.
The generation call uses `qwen-plus`, temperature 0, seed 20261111, no thinking,
and a 1024-token output limit. Judging uses `qwen-max`, blinded A/B assignments,
then reversed display order. Question/arm execution order is fixed in the protocol.

Timing starts at the direct service call and excludes retrieval and HTTP transport.
The measured first return is application content, not model time to first token.
The twenty purposively selected cases cover five sources and seventeen target
clusters; the reported resampling interval describes this diagnostic set.
