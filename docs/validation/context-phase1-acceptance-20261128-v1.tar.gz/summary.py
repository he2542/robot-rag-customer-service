"""Recompute the frozen paired acceptance using saved responses only."""
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import statistics
import sys

ARMS = ('baseline', 'candidate')

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def quantiles(values):
    ordered = sorted(values)
    def p(prob):
        position = (len(ordered) - 1) * prob
        left = int(position); right = min(left + 1, len(ordered) - 1)
        return ordered[left] + (ordered[right] - ordered[left]) * (position - left)
    return {'n': len(values), 'mean': statistics.mean(values), 'p50': p(.5), 'p95': p(.95)}

def summarize(root, paired_binary):
    frozen = read(root / 'inputs.json')
    manifest = read(root / 'manifest.json')
    assert all(digest(root / name) == manifest[name] for name in ('inputs.json', 'budget.json'))
    assert not (root / 'completed.json').exists()
    failure = read(root / 'failure.json'); assert failure['type'] == 'HTTPStatusError'
    cached = set(manifest['generation_cache'])
    assert cached == set(manifest['generation_cache']) and len(cached) == 20
    ledger = read(root / 'budget.json.usage.json')
    assert ledger['calls_reserved'] == 818 and len(ledger['events']) == 818
    budget = read(root / 'budget.json')
    assert Decimal(ledger['estimated_cost_cny_exposure']) <= Decimal(budget['max_estimated_cost_cny'])
    assert ledger['input_bytes_reserved'] <= budget['max_input_bytes']
    assert ledger['output_tokens_reserved'] <= budget['max_output_tokens']
    events = {e['attempt']: e for e in ledger['events']}
    usage = {model: {'calls': 0, 'input_tokens': 0, 'output_tokens': 0} for model in ['qwen-plus', 'qwen-max']}
    pending, rows, all_gen_usage, old_gen_usage, latency = [], [], [], [], []
    receipts = set()

    def account(raw, model):
        ticket = raw['budget_attempt']
        assert ticket not in receipts
        receipts.add(ticket)
        event = events[ticket]
        assert event['model'] == model and event['input_sha256'] == raw['input_sha256']
        assert event['output_tokens'] == (1024 if model == 'qwen-plus' else 2200)
        usage[model]['calls'] += 1
        for key in ['input_tokens', 'output_tokens']:
            value = raw['usage'][key]
            assert type(value) is int and value >= 0
            usage[model][key] += value
        if event.get('settled'):
            assert raw['finish_reason'] == 'stop'
            assert event['input_tokens'] == raw['usage']['input_tokens']
            assert event['actual_output_tokens'] == raw['usage']['output_tokens']

    for row in frozen['rows']:
        q = row['question']; qid = q['id']
        gen = read(root / 'outputs' / f'{qid}-generation.json')
        answer = read(root / 'outputs' / f'{qid}-answer.json')
        assert answer['sources'] == row['sources']
        assert answer['finish_reason'] == gen['finish_reason']
        if qid in cached:
            assert gen == read(root / 'generation-cache' / f'{qid}.json')
        else:
            account(gen, 'qwen-plus')
        all_gen_usage.append(gen['usage'])
        old_gen_usage.append(row['baseline']['generation_info']['token_usage'])
        latency.append(gen['elapsed_ms'])
        grades, passed, cited = [], {a: [] for a in ARMS}, {a: [] for a in ARMS}
        for k in range(2):
            if not (root / 'outputs' / f'{qid}-judge{k}.json').exists():
                assert k == 1 and int(qid[1:]) >= 238
                for a in ARMS: passed[a].append(None); cited[a].append(None)
                grades.append(None)
                continue
            raw = read(root / 'outputs' / f'{qid}-judge{k}-raw.json')
            account(raw, 'qwen-max')
            result = read(root / 'outputs' / f'{qid}-judge{k}.json')
            expected = row['order'] if k == 0 else list(reversed(row['order']))
            assert result['order'] == expected
            if result['review_required']:
                pending.append({'id': qid, 'round': k, 'reason': 'format_or_unsafe_quote'})
            for a in ARMS:
                g = (result['scores'] or {}).get(a)
                finish = row['baseline']['generation_info']['finish_reason'] if a == 'baseline' else gen['finish_reason']
                passed[a].append(None if g is None else bool(g['correct'] and g['supported'] and not g['unsafe_advice'] and finish == 'stop'))
                cited[a].append(None if g is None else g['citation_supported'])
            grades.append(result)
        rows.append({'id': qid, 'query': q['query'], 'source': q['source'], 'cluster': q['cluster'],
                     'risk': q['safety_expected'], 'required_points': q['required_points'],
                     'baseline': row['baseline']['answer'], 'candidate': answer['answer'],
                     'generation_complete': gen['finish_reason'] == 'stop',
                     'pass': passed, 'citation_supported': cited, 'scores': grades,
                     'both_pass': {a: None if None in passed[a] else all(passed[a]) for a in ARMS}})
    assert receipts == set(range(1, 818))
    assert len(rows) == 300 and len({r['id'] for r in rows}) == 300
    rounds = []
    for k in range(2):
        valid = [r for r in rows if all(r['pass'][a][k] is not None for a in ARMS)]
        stat = paired_binary([{'before': r['pass']['baseline'][k], 'after': r['pass']['candidate'][k],
                               'source': r['source'], 'cluster': r['cluster']} for r in valid])
        rounds.append({'complete_pairs': len(valid), 'metrics': stat,
                       'citation_supported': {a: sum(r['citation_supported'][a][k] is True for r in rows) for a in ARMS},
                       'risk': {a: sum(r['pass'][a][k] is True for r in rows if r['risk']) for a in ARMS}})
    valid = [r for r in rows if all(r['both_pass'][a] is not None for a in ARMS)]
    both = paired_binary([{'before': r['both_pass']['baseline'], 'after': r['both_pass']['candidate'],
                           'source': r['source'], 'cluster': r['cluster']} for r in valid])
    unsafe = {a: [r['id'] for r in rows if any(((s or {}).get('scores') or {}).get(a, {}).get('unsafe_advice') for s in r['scores'])] for a in ARMS}
    disagreements = [r['id'] for r in rows if any(None not in r['pass'][a] and r['pass'][a][0] != r['pass'][a][1] for a in ARMS)]
    changed = [r['id'] for r in rows if r['baseline'] != r['candidate']]
    cost = sum(Decimal(usage[model]['input_tokens']) * Decimal(inp) + Decimal(usage[model]['output_tokens']) * Decimal(out)
               for model, inp, out in [('qwen-plus', '.8', '2'), ('qwen-max', '2.4', '9.6')]) / 1000000
    generation_tokens = {arm: {key: sum(u[key] for u in us) for key in ['input_tokens', 'output_tokens']}
                         for arm, us in [('baseline_archived', old_gen_usage), ('candidate_including_20_cache', all_gen_usage)]}
    risk_both = {a: sum(r['both_pass'][a] is True for r in rows if r['risk']) for a in ARMS}
    numeric_gate = (not pending and all(r['complete_pairs'] == 300 and r['metrics']['after_correct'] > r['metrics']['before_correct'] for r in rounds)
                    and risk_both['candidate'] >= risk_both['baseline'])
    return {'questions': 300, 'status': 'stopped_on_http_500', 'completed_generation': 300, 'new_generation_calls': 280, 'completed_judgments': 537, 'attempts': 818, 'failed_attempts': 1, 'missing_judgments': 63, 'baseline_commit': frozen['baseline_commit'],
            'input_sha256': manifest['inputs.json'], 'rounds': rounds, 'both_rounds': both,
            'risk_questions': sum(r['risk'] for r in rows), 'risk_both_rounds': risk_both,
            'unsafe_ids': unsafe, 'format_review': pending, 'disagreement_ids': disagreements,
            'answer_changed_count': len(changed), 'generation_incomplete_ids': [r['id'] for r in rows if not r['generation_complete']],
            'numeric_gate_passed': numeric_gate, 'failure': failure, 'both_rounds_scope': '236 valid pairs from 237 returned second-round responses; one invalid response and 63 unrequested; not a full 300-question result',
            'usage_new_calls': usage, 'cached_generations': 20, 'estimated_token_cost_cny': str(cost), 'failed_request_usage': 'unknown; retained full reservation',
            'actual_bill': 'not_read', 'budget_exposure_cny': ledger['estimated_cost_cny_exposure'],
            'unsettled_attempts': [e['attempt'] for e in ledger['events'] if not e.get('settled')],
            'generation_token_comparison': generation_tokens,
            'candidate_generation_latency_ms_including_cache': quantiles(latency), 'per_question': rows}

if __name__ == '__main__':
    import importlib.util
    path = Path(sys.argv[2]); spec = importlib.util.spec_from_file_location('paired', path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    result = summarize(Path(sys.argv[1]), module.paired_binary)
    with (Path(sys.argv[1]) / 'summary.json').open('x', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(json.dumps({k: v for k, v in result.items() if k != 'per_question'}, ensure_ascii=False, indent=2))
