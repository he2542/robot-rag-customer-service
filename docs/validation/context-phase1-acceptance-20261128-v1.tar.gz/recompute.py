"""Recompute with the Python standard library; no model calls."""
import hashlib,json,runpy,socket
from pathlib import Path
root=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in read(root/'artifact-manifest.json').items():
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert sha(root/name)==digest,name
def deny(*a,**kw):raise AssertionError('Network forbidden')
socket.socket.connect=deny
socket.socket.connect_ex=deny
policy=runpy.run_path(str(root/'snapshot/src/services/answer_policy.py'))['render_context_answer']
functions=runpy.run_path(str(root/'final.py'))
stats=runpy.run_path(str(root/'paired_statistics.py'))['paired_binary']
summary=runpy.run_path(str(root/'summary.py'))['summarize'](root/'run',stats)
assert summary==read(root/'run/summary.json')
def body(model,messages,tokens):return {'model':model,'input':{'messages':messages},'parameters':{
    'result_format':'message','temperature':0,'seed':20261111,'enable_thinking':False,
    'max_tokens':tokens,'response_format':{'type':'json_object'}}}
def request_hash(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
baseline_manifest=read(root/'baseline-manifest.json')
inputs=read(root/'run/inputs.json')
for row in inputs['rows']:
    q=row['question'];i=q['id'];prefix=root/'run/outputs'
    assert sha(root/'baseline'/f'{i}-old.json')==baseline_manifest[f'{i}-old.json']
    assert row['baseline']==read(root/'baseline'/f'{i}-old.json')
    generation=read(prefix/f'{i}-generation.json');answer=read(prefix/f'{i}-answer.json')
    assert generation['input_sha256']==request_hash(body('qwen-plus',row['messages'],1024))
    assert policy(generation['text'],row['sources'],q['query'],extractive_quotes=True)==answer['answer'],i
    for k in range(2):
        order=row['order'] if not k else list(reversed(row['order']))
        payload=functions['payload'](row,answer['answer'],order)
        messages=[{'role':'system','content':inputs['judge']},
                  {'role':'user','content':json.dumps(payload,ensure_ascii=False)}]
        if not (prefix/f'{i}-judge{k}.json').exists():
            assert k==1 and int(i[1:])>=238
            continue
        raw=read(prefix/f'{i}-judge{k}-raw.json')
        assert raw['input_sha256']==request_hash(body('qwen-max',messages,2200)),(i,k)
        record=read(prefix/f'{i}-judge{k}.json')
        try:grade=functions['typed_grade'](raw['text']) if raw['finish_reason']=='stop' else None
        except (ValueError,AssertionError,KeyError,TypeError):grade=None
        expected={arm:grade[a] for a,arm in zip(['A','B'],order)} if grade else None
        assert record['scores']==expected,(i,k)
replay=read(root/'run/runtime-replay.json')
assert replay['questions']==300 and all(all(v for k,v in r.items() if k!='id') for r in replay['rows'])
print(json.dumps({k:v for k,v in summary.items() if k!='per_question'},ensure_ascii=False,indent=2))
