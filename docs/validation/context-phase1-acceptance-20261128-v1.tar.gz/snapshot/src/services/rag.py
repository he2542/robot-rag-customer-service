"""Grounded robot customer-service answers over a managed internal corpus."""

import json
import logging
import re

from langchain_community.embeddings import DashScopeEmbeddings
from langchain_community.chat_models.tongyi import ChatTongyi
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables import RunnableLambda, RunnableWithMessageHistory
from langchain_core.messages import SystemMessage

from src import config
from src.history import FileChatMessageHistory
from src.services.retrieval import InternalKnowledgeRetriever

from .prompts import SYSTEM_PROMPT, CONTEXT_SYSTEM_PROMPT, NAVIGATION_CONTEXT_SYSTEM_PROMPT, EXTRACTIVE_CONTEXT_SYSTEM_PROMPT
from .context import EvidenceContextBuilder
from .prompt_context import PromptContextBuilder, source_items
from .answer_policy import render_context_answer

logger = logging.getLogger(__name__)


def internal_history(session_id):
    return FileChatMessageHistory(session_id, str(config.DATA_ROOT / "chat_history" / "robot_internal_v1"))


def filter_citations(text, allowed):
    return re.sub(r"\[\s*((?:S)?\d[^\]\n]*)\]",
                  lambda match: f"[{match.group(1).strip()}]"
                  if match.group(1).strip() in allowed else "", text)


class RagService:
    def __init__(self, retriever=None, chat_model=None, history_factory=internal_history,
                 *, context_builder=None, context_entries_enabled=None, context_system_prompt=None, context_navigation_enabled=None, context_extractive_quotes=None):
        self.retriever = retriever if retriever is not None else InternalKnowledgeRetriever(
            DashScopeEmbeddings(model=config.embedding_model_name)
        )
        self.chat_model = chat_model if chat_model is not None else ChatTongyi(
            model=config.chat_model_name, max_retries=1,
            model_kwargs={"enable_thinking": False, "max_tokens": 1024},
        )
        self.context_entries_enabled = (config.context_entries_enabled if context_entries_enabled is None
                                        else context_entries_enabled)
        self.context_builder = context_builder if context_builder is not None else EvidenceContextBuilder()
        context_navigation_enabled = (config.context_navigation_enabled if context_navigation_enabled is None
                                      else context_navigation_enabled)
        context_extractive_quotes = (config.context_extractive_quotes if context_extractive_quotes is None
                                     else context_extractive_quotes)
        self.context_extractive_quotes = context_extractive_quotes
        default_prompt = (EXTRACTIVE_CONTEXT_SYSTEM_PROMPT if context_extractive_quotes else
                          NAVIGATION_CONTEXT_SYSTEM_PROMPT if context_navigation_enabled else CONTEXT_SYSTEM_PROMPT)
        self.context_system_prompt = default_prompt if context_system_prompt is None else context_system_prompt
        self.prompt_context = PromptContextBuilder(self.context_system_prompt, navigation_enabled=context_navigation_enabled)
        prompt = ChatPromptTemplate.from_messages([
            ("system", SYSTEM_PROMPT), MessagesPlaceholder("history"),
            ("human", "{request_payload}"),
        ])
        chain = RunnableLambda(lambda value: {
            "history": value.get("history", [])[-12:],
            "request_payload": json.dumps({
                "question": value["input"],
                "references": source_items(value["documents"]),
            }, ensure_ascii=False),
        }) | prompt | self.chat_model | StrOutputParser()
        self.chain = RunnableWithMessageHistory(
            RunnableLambda(self._generate_context_answer) if self.context_entries_enabled else chain, history_factory, input_messages_key="input", history_messages_key="history",
        )

    def _generate_context_answer(self, value):
        prepared, diagnostic = self.prompt_context.messages(
            value["input"], value["documents"], value.get("history", []))
        logger.info("Prompt context bytes=%d evidence_bytes=%d history_messages=%d history_dropped=%d",
                    diagnostic["input_bytes"], diagnostic["evidence_bytes"],
                    diagnostic["history_messages"], diagnostic["history_dropped"])
        prompt = ChatPromptTemplate.from_messages([
            SystemMessage(content=self.context_system_prompt), MessagesPlaceholder("history"),
            ("human", "{request_payload}"),
        ]).invoke(prepared)
        options = {"response_format": {"type": "json_object"}} if isinstance(self.chat_model, ChatTongyi) else {}
        response = self.chat_model.invoke(prompt, **options)
        usage = getattr(response, "response_metadata", {}).get("token_usage", {})
        if isinstance(usage, dict):
            logger.info("Generation usage input_tokens=%s output_tokens=%s cached_tokens=%s",
                        usage.get("input_tokens"), usage.get("output_tokens"),
                        usage.get("prompt_tokens_details", {}).get("cached_tokens")
                        if isinstance(usage.get("prompt_tokens_details"), dict) else None)
        result = StrOutputParser().invoke(response)
        if self.context_extractive_quotes:
            return render_context_answer(result, source_items(value["documents"]), value["input"], extractive_quotes=True)
        return render_context_answer(result, source_items(value["documents"]), value["input"])

    def stream_answer(self, query: str, session_id: str):
        risk_terms = ("鼓包", "冒烟", "烧焦", "起火", "漏电", "短接", "带电维修", "拆电池")
        if any(term in query for term in risk_terms):
            yield {"sources": []}
            yield {"content": "涉及电池、电气或起火风险，请停止使用和充电，在确保自身安全的前提下远离设备，联系专业售后；不要自行拆修或继续测试。"}
            return
        documents = self.retriever.invoke(query)
        if self.context_entries_enabled:
            context = self.context_builder.build(documents)
            packed = self.prompt_context.evidence(query, context.documents)
            documents = list(packed.documents)
            logger.info("Evidence duplicates=%d omitted_units=%d serialized_bytes=%d",
                        packed.duplicates, packed.dropped_units, packed.evidence_bytes)
            logger.info("Evidence entries=%d reviews=%s fallback_count=%d",
                        context.entry_count, context.excluded_reviews, len(context.fallback_reasons))
        yield {"sources": source_items(documents)}
        if not documents:
            yield {"content": "当前内置知识库没有找到可用资料，无法据此确认。请补充型号或问题细节，必要时联系对应品牌售后。"}
            return
        allowed = {f"S{index}" for index in range(1, len(documents) + 1)}
        pending = ""
        for chunk in self.chain.stream(
            {"input": query, "documents": documents},
            config={"configurable": {"session_id": session_id}},
        ):
            if not chunk:
                continue
            pending += chunk
            # Keep an incomplete citation until its closing bracket arrives.
            opening = pending.rfind("[")
            boundary = opening if opening >= 0 and "]" not in pending[opening:] else len(pending)
            text, pending = pending[:boundary], pending[boundary:]
            cleaned = filter_citations(text, allowed)
            if cleaned:
                yield {"content": cleaned}
        if pending:
            cleaned = re.sub(r"\[\s*S?\d[^\]\n]*$", "", filter_citations(pending, allowed))
            if cleaned:
                yield {"content": cleaned}


class ChatUnavailable(Exception):
    """Safe public business error; HTTP mapping belongs to routes."""


class EmptyQuestion(Exception):
    pass


def prepare_question(text: str, knowledge: dict) -> str:
    if not config.model_configured():
        raise ChatUnavailable("模型待配置，请管理员配置 DashScope API Key 后启用服务")
    query = text.strip()
    if not query:
        raise EmptyQuestion("问题不能为空")
    if not knowledge["ready"]:
        raise ChatUnavailable("内置知识库尚未就绪，请管理员完成资料导入")
    return query
