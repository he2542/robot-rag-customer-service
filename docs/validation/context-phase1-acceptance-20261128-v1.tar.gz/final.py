"""Paired frozen 300-question acceptance. No paid work without explicit budget."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import tarfile
import time

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2)
def context(sources):return '\n\n'.join('['+s['id']+'] '+s['filename']+'\n'+s['excerpt'] for s in sources)
def payload(row,candidate,order):
    q=row['question'];result={'question':q['query'],'source_item':q['passage'],'reference':q['reference'],
        'required_points':q['required_points'],'safety_expected':q['safety_expected']}
    records={'baseline':{'answer':row['baseline']['answer'],'context':context(row['baseline']['sources'])},
             'candidate':{'answer':candidate,'context':context(row['sources'])}}
    for letter,arm in zip(['A','B'],order):result[letter]=records[arm]
    return result
def typed_grade(text):
    grade=json.loads(text)
    assert type(grade.get('reference_valid')) is bool
    for letter in ['A','B']:
        g=grade[letter]
        assert all(type(g.get(k)) is bool for k in ['correct','supported','context_sufficient','citation_supported','unsafe_advice'])
        assert all(isinstance(g.get(k),str) for k in ['reason','citation_reason','unsafe_quote'])
        if g['unsafe_advice']:g['correct']=False
    return grade
def quote_format(grade,p):
    return all(not grade[a]['unsafe_advice'] or bool(grade[a]['unsafe_quote'] and
        grade[a]['unsafe_quote'].replace('**','') in p[a]['answer'].replace('**','')) for a in ['A','B'])

def prepare(repo,root):
    sys.path.insert(0,str(repo/'services/backend'))
    from langchain_core.documents import Document
    from langchain_core.chat_history import InMemoryChatMessageHistory
    from langchain_core.runnables import RunnableLambda
    from src.services.rag import RagService
    from src.services.context import EvidenceContextBuilder
    from src.services.corpus import load_internal_files
    from evaluation.postprocess_validation import make_body,size
    archive=repo/'docs/validation/phase1-context-300-20261116-v1.tar.gz';content={}
    with tarfile.open(archive) as tar:
        manifest=json.load(tar.extractfile('artifact-manifest.json'))
        for member in tar:
            if member.isfile() and (member.name in ['dataset.json','corpus.json','judge_prompt.txt','protocol.json'] or member.name.startswith('answers/') and member.name.endswith('-old.json')):
                raw=tar.extractfile(member).read();assert hashlib.sha256(raw).hexdigest()==manifest[member.name]
                content[member.name]=raw
    data=json.loads(content['dataset.json']);corpus={r['id']:r for r in json.loads(content['corpus.json'])};old_protocol=json.loads(content['protocol.json'])
    assert len(data['questions'])==300 and len({q['id'] for q in data['questions']})==300
    rows=[];maximum={'generation':0,'judge':0}
    for q in data['questions']:
        i=q['id'];captured=[];history=InMemoryChatMessageHistory()
        class Retriever:
            def invoke(self,query):return [Document(id=k,page_content=corpus[k]['content'],metadata=corpus[k]['metadata']) for k in q['frozen_chunk_ids']]
        def model(prompt):
            captured.extend({'role':{'human':'user','ai':'assistant'}.get(m.type,m.type),'content':m.content} for m in prompt.to_messages())
            return '{"decision":"insufficient","claims":[],"question":""}'
        service=RagService(Retriever(),RunnableLambda(model),lambda _:history,context_entries_enabled=True,
                context_navigation_enabled=True,context_extractive_quotes=True,
                context_builder=EvidenceContextBuilder(lambda:load_internal_files(repo/'knowledge/robot')))
        events=list(service.stream_answer(q['query'],'prepare-'+i));sources=events[0]['sources']
        assert len(captured)==2 and json.loads(captured[-1]['content'])['references']==sources
        baseline=json.loads(content[f'answers/{i}-old.json'])
        order=[{'old':'baseline','new':'candidate'}[arm] for arm in old_protocol['judge_order'][i]]
        row={'question':q,'messages':captured,'sources':sources,'baseline':baseline,'order':order}
        n=size(make_body('qwen-plus',captured,1024,20261111));assert n<=32768,(i,n);maximum['generation']=max(maximum['generation'],n)
        for ordering in [order,list(reversed(order))]:
            messages=[{'role':'system','content':content['judge_prompt.txt'].decode()},
                      {'role':'user','content':json.dumps(payload(row,'X'*8192,ordering),ensure_ascii=False)}]
            n=size(make_body('qwen-max',messages,2200,20261111));assert n<=40960,(i,n);maximum['judge']=max(maximum['judge'],n)
        rows.append(row)
    root.mkdir(exist_ok=False)
    write(root/'inputs.json',{'rows':rows,'judge':content['judge_prompt.txt'].decode(),'seed':20261111,
        'parent_archive_sha256':sha(archive),'baseline_commit':'2c0129773ca20710948cf194aa7a49fe747077c0',
        'criteria':'Both paired rounds strictly exceed same-batch baseline; original risk subset does not regress; all scoring disagreements and risks reviewed before merge'})
    write(root/'budget.json',{'max_calls':900,'max_input_bytes':33*1024*1024,'max_output_tokens':1627200,
        'max_output_tokens_per_call':2200,'max_estimated_cost_cny':'20','settle_successful_usage':True,
        'models':{'qwen-plus':{'input_per_million_cny':'.8','output_per_million_cny':'2'},
                  'qwen-max':{'input_per_million_cny':'2.4','output_per_million_cny':'9.6'}}})
    write(root/'preflight.json',{'questions':300,'paid_calls':0,'max_request_bytes':maximum})
    write(root/'manifest.json',{'inputs.json':sha(root/'inputs.json'),'budget.json':sha(root/'budget.json'),'runner_sha256':sha(Path(__file__)),
        'source_files':{f.relative_to(repo/'services/backend').as_posix():sha(f) for folder in ['src','evaluation'] for f in (repo/'services/backend'/folder).rglob('*.py') if '__pycache__' not in f.parts}})
    print(json.dumps({'prepared':300,'max_request_bytes':maximum,'paid_calls':0,'input_sha256':sha(root/'inputs.json')}))

def run(root,args):
    import httpx
    from evaluation.budget import budget_from_args
    from evaluation.postprocess_validation import call,make_body,hash_value
    from src.services.answer_policy import render_context_answer
    m=read(root/'manifest.json');assert sha(Path(__file__))==m['runner_sha256']
    assert all(sha(root/n)==m[n] for n in ['inputs.json','budget.json'])
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in m['source_files'])
    assert set(m.get('generation_cache',{}))<={f'b{i:03d}' for i in range(1,301)}
    assert all(sha(Path(__file__).parent/n)==v for n,v in m['source_files'].items())
    assert all(sha(root/'generation-cache'/f'{i}.json')==v for i,v in m.get('generation_cache',{}).items())
    assert not (root/'outputs').exists(),'No automatic resume/retry'
    data=read(root/'inputs.json');assert len(data['rows'])==300
    assert {r['question']['id'] for r in data['rows']}=={f'b{i:03d}' for i in range(1,301)}
    assert all(sorted(r['order'])==['baseline','candidate'] for r in data['rows'])
    fresh_generation=0;cached_ids=[]
    with budget_from_args(args) as budget,httpx.Client(timeout=90,trust_env=False) as client:
        (root/'outputs').mkdir()
        try:
            for row in data['rows']:
                i=row['question']['id'];cached=i in m.get('generation_cache',{})
                if cached:
                    raw=read(root/'generation-cache'/f'{i}.json')
                    assert raw['input_sha256']==hash_value(make_body('qwen-plus',row['messages'],1024,20261111))
                    assert raw['finish_reason']=='stop'
                    cached_ids.append(i)
                else:
                    raw=call(client,'qwen-plus',row['messages'],1024,20261111,32768)
                    fresh_generation+=1
                write(root/'outputs'/f'{i}-generation.json',raw)
                answer=render_context_answer(raw['text'],row['sources'],row['question']['query'],extractive_quotes=True)
                assert len(answer.encode())<=8192,'Answer exceeds preflight allowance'
                write(root/'outputs'/f'{i}-answer.json',{'answer':answer,'finish_reason':raw['finish_reason'],'sources':row['sources']})
                if not cached and raw['finish_reason']=='stop':
                    try:parsed=json.loads(raw['text']);valid=isinstance(parsed,dict) and parsed.get('decision') in ['answer','conflict','clarify','insufficient','refer']
                    except ValueError:valid=False
                    if valid:budget.settle_successful_result(raw)
                print(json.dumps({'generation':i}),flush=True)
            for k in range(2):
                for row in data['rows']:
                    i=row['question']['id'];answer=read(root/'outputs'/f'{i}-answer.json')['answer'];order=row['order'].copy()
                    if k:order.reverse()
                    p=payload(row,answer,order)
                    messages=[{'role':'system','content':data['judge']},{'role':'user','content':json.dumps(p,ensure_ascii=False)}]
                    result=call(client,'qwen-max',messages,2200,20261111,40960)
                    write(root/'outputs'/f'{i}-judge{k}-raw.json',result)
                    grade=None;valid=False
                    if result['finish_reason']=='stop':
                        try:grade=typed_grade(result['text']);valid=quote_format(grade,p)
                        except (ValueError,AssertionError,KeyError,TypeError):grade=None
                    record={'order':order,'format_valid':valid,'scores':{arm:grade[a] for a,arm in zip(['A','B'],order)} if grade else None,
                            'reference_valid':grade.get('reference_valid') if grade else None,
                            'review_required':not valid}
                    write(root/'outputs'/f'{i}-judge{k}.json',record)
                    if valid:budget.settle_successful_result(result)
                    print(json.dumps({'judged':i,'round':k,'review_required':not valid}),flush=True)
            write(root/'cache-reused.json',{'generation_ids':cached_ids})
            write(root/'completed.json',{'questions':300,'generation_calls':fresh_generation,'generation_cache_reused':len(cached_ids),'judge_calls':600})
        except Exception as error:
            write(root/'failure.json',{'type':type(error).__name__,'message':'Stopped; inspect preserved raw responses and budget ledger'})
            raise

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['prepare','run']);p.add_argument('--repo',type=Path);p.add_argument('--root',type=Path,required=True)
    p.add_argument('--allow-paid',action='store_true');p.add_argument('--budget',type=Path);a=p.parse_args()
    if a.stage=='prepare':prepare(a.repo,a.root)
    else:run(a.root,a)
