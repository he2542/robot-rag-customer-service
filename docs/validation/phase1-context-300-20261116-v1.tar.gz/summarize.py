"""Offline aggregation. Requires all 600 answers and both blinded judge rounds."""
from collections import Counter, defaultdict
import argparse
import hashlib
import json
from pathlib import Path
import statistics

from paired_statistics import paired_binary, percentile

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main(output=None):
    data = read(ROOT / "dataset.json")
    protocol = read(ROOT / "protocol.json")
    assert sha(ROOT / "dataset.json") == protocol["dataset_sha256"]
    assert len(data["questions"]) == 300
    records = []
    answer_flags = {}
    for q in data["questions"]:
        answers = {arm: read(ROOT / "answers" / f"{q['id']}-{arm}.json") for arm in ("old", "new")}
        answer_flags[q["id"]] = {arm: {k: a[k] for k in ("has_citations", "citation_ids_valid")}
                                 for arm, a in answers.items()}
        rounds = {name: read(ROOT / name / f"{q['id']}.json") for name in ("judgments", "judge_swapped")}
        for j in rounds.values():
            assert j["dataset_sha256"] == protocol["dataset_sha256"]
            for arm in ("old", "new"):
                assert j["answer_sha256"][arm] == sha(ROOT / "answers" / f"{q['id']}-{arm}.json")
        assert rounds["judgments"]["blinded_order"] == list(reversed(rounds["judge_swapped"]["blinded_order"]))
        assert answers["old"]["chunk_ids"] == answers["new"]["chunk_ids"]
        row = {"id": q["id"], "source": q["source"], "cluster": q["cluster"],
               "query": q["query"], "safety_expected": q["safety_expected"],
               "target_hit_at4": bool(set(q["labeled_chunk_ids"]) & set(q["frozen_chunk_ids"])),
               "reference_valid": {r: j["reference_valid"] for r, j in rounds.items()},
               "scores": {r: j["scores"] for r, j in rounds.items()}}
        row["pass"] = {arm: {r: bool(j["scores"][arm]["correct"] and j["scores"][arm]["supported"])
                             for r, j in rounds.items()} for arm in ("old", "new")}
        row["raw_pass"] = {arm: dict(row["pass"][arm]) for arm in ("old", "new")}
        row["finish_stop"] = {arm: a["generation_info"]["finish_reason"] == "stop" for arm, a in answers.items()}
        row["pass"] = {arm: {r: passed and row["finish_stop"][arm] for r, passed in flags.items()}
                       for arm, flags in row["pass"].items()}
        row["both_pass"] = {arm: all(row["pass"][arm].values()) for arm in ("old", "new")}
        records.append(row)

    def paired(selector, selected=records):
        return paired_binary([{"before": selector(r, "old"), "after": selector(r, "new"),
                               "source": r["source"], "cluster": r["cluster"]} for r in selected],
                             replicates=20000, seed=20261115)

    quality = {r: paired(lambda row, arm: row["pass"][arm][r]) for r in ("judgments", "judge_swapped")}
    quality["both_rounds"] = paired(lambda row, arm: row["both_pass"][arm])
    raw_citations = {r: paired(lambda row, arm, r=r: row["scores"][r][arm]["citation_supported"])
                 for r in ("judgments", "judge_swapped")}
    def citation_pass(row, arm, round_name):
        flags = answer_flags[row["id"]][arm]
        return bool(flags["has_citations"] and flags["citation_ids_valid"]
                    and row["scores"][round_name][arm]["citation_supported"])
    citations = {r: paired(lambda row, arm, r=r: citation_pass(row, arm, r))
                 for r in ("judgments", "judge_swapped")}
    citations["both_rounds"] = paired(lambda row, arm: all(citation_pass(row, arm, r)
                                                          for r in ("judgments", "judge_swapped")))
    missing_citation_false_positives = {r: {arm: [row["id"] for row in records
        if row["scores"][r][arm]["citation_supported"] and not answer_flags[row["id"]][arm]["has_citations"]]
        for arm in ("old", "new")} for r in ("judgments", "judge_swapped")}
    risk = [r for r in records if r["safety_expected"]]
    def risk_counts(selector):
        return {"n": len(risk), "old": sum(selector(row, "old") for row in risk),
                "new": sum(selector(row, "new") for row in risk)}
    risk_quality = {r: risk_counts(lambda row, arm, r=r: row["pass"][arm][r])
                    for r in ("judgments", "judge_swapped")}
    risk_quality["both_rounds"] = risk_counts(lambda row, arm: row["both_pass"][arm])
    perf = {}
    for arm in ("old", "new"):
        rows = [read(ROOT / "answers" / f"{q['id']}-{arm}.json") for q in data["questions"]]
        usage = [r["generation_info"]["token_usage"] for r in rows]
        cached = [u.get("input_tokens_details", u.get("prompt_tokens_details", {})).get("cached_tokens")
                  for u in usage]
        values = {}
        for key in ("elapsed_ms", "first_content_ms", "first_model_token_ms"):
            observations = [r[key] for r in rows if isinstance(r[key], (float, int))]
            if key == "elapsed_ms":
                assert len(observations) == len(rows)
            values[key] = {"n_observed": len(observations),
                           "median": statistics.median(observations) if observations else None,
                           "p95": percentile(observations, .95) if observations else None,
                           "mean": statistics.mean(observations) if observations else None}
        perf[arm] = {"n": len(rows), "input_tokens": sum(u["input_tokens"] for u in usage),
                     "output_tokens": sum(u["output_tokens"] for u in usage),
                     "cached_tokens": sum(cached) if all(isinstance(x, int) for x in cached) else None,
                     "raw_usage_examples": usage[:2], **values,
                     "citation_ids_valid": sum(r["citation_ids_valid"] for r in rows),
                     "has_citations": sum(r["has_citations"] for r in rows),
                     "all_finish_stop": all(r["generation_info"]["finish_reason"] == "stop" for r in rows)}
    agreements = {arm: sum(r["raw_pass"][arm]["judgments"] == r["raw_pass"][arm]["judge_swapped"] for r in records)
                  for arm in ("old", "new")}
    by_source = {}
    for source in sorted({r["source"] for r in records}):
        rows = [r for r in records if r["source"] == source]
        by_source[source] = {arm: sum(r["pass"][arm]["judgments"] for r in rows) for arm in ("old", "new")}
    judgment_usage = Counter()
    for folder in ("judgments", "judge_swapped"):
        for path in (ROOT / folder).glob("*.json"):
            judgment_usage.update({k: v for k, v in read(path)["usage"].items() if isinstance(v, int)})
    result = {"dataset_version": data["version"], "dataset_sha256": sha(ROOT / "dataset.json"),
              "old_commit": protocol["old_commit"], "new_commit": protocol["new_commit"],
              "questions": len(records), "source_counts": dict(Counter(r["source"] for r in records)),
              "quality": quality,
              "quality_raw_model": {r: paired(lambda row, arm, r=r: row["raw_pass"][arm][r])
                                    for r in ("judgments", "judge_swapped")},
              "generation_truncations": {arm: [r["id"] for r in records if not r["finish_stop"][arm]] for arm in ("old", "new")}, "citation_support": citations,
              "citation_support_raw_model": raw_citations,
              "citation_false_positives_without_markers": missing_citation_false_positives,
              "risk_quality": risk_quality,
              "audit": {
                  "primary_scores_rule": "Primary pass requires correct AND supported AND finish_reason=stop. Unsafe advice requires a literal answer quote and fails correctness. Raw model scores are also retained.",
                  "citation_rule": "A response must actually contain a valid bracketed source marker before model citation support can pass; absence deterministically fails under the frozen rubric.",
                  "risk_review_file": "qualitative-review.json",
                  "model_token_callback": "No first-model-token event was captured. Report first application content latency, not model TTFT.",
                  "timing": protocol["timing"],
                  "interval_scope": "Frozen course-derived 300-question regression set; source-stratified cluster bootstrap describes this set. Risk subset reported as counts."},
              "judge_agreement": {**agreements, "total_agree": sum(agreements.values()), "total": 600},
              "judge_disagreement_ids": [r["id"] for r in records if any(
                  r["raw_pass"][a]["judgments"] != r["raw_pass"][a]["judge_swapped"] for a in ("old", "new"))],
              "reference_invalid": [r["id"] for r in records if not all(r["reference_valid"].values())],
              "by_source_first_round": by_source, "performance": perf,
              "target_hit_at4": {"old": sum(r["target_hit_at4"] for r in records),
                                  "new": sum(r["target_hit_at4"] for r in records), "n": 300},
              "judge_usage": dict(judgment_usage),
              "failed_attempts": len(list((ROOT / "failures").glob("*.json"))),
              "unsafe_advice": {r: {arm: [row["id"] for row in records
                  if row["scores"][r][arm]["unsafe_advice"]] for arm in ("old", "new")}
                  for r in ("judgments", "judge_swapped")},
              "structured_output": {"new": {
                  "protocol_fallback": [q["id"] for q in data["questions"] if read(ROOT / "answers" / f"{q['id']}-new.json")["answer"].startswith("当前无法提供")],
                  "safe_action_replacement": [q["id"] for q in data["questions"] if read(ROOT / "answers" / f"{q['id']}-new.json")["answer"].startswith("涉及内部电机")]}},
              "per_question": records}
    path = Path(output) if output else ROOT / "summary.json"
    with path.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    brief = {k: result[k] for k in ("quality", "citation_support", "risk_quality", "judge_agreement",
                                    "judge_disagreement_ids", "reference_invalid", "performance", "failed_attempts")}
    print(json.dumps(brief, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", help="Write a new summary without overwriting the published result")
    main(parser.parse_args().output)
