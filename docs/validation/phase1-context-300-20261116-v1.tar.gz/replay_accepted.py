import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import time

root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
import runner
from langchain_core.runnables import RunnableLambda

prior=Path(sys.argv[1])
questions,protocol=runner.checked()
changed=[]
for path in sorted((root/'observed_answers').glob('*.json')):
    observed=runner.read(path)
    previous=runner.read(prior/'answers'/path.name)
    q,arm=questions[observed['id']],observed['arm']
    captured=[]
    def model(value):
        captured.extend(runner.serialize(value.to_messages()))
        return observed['raw_generation']
    start=time.perf_counter()
    service,history=runner.build(q,arm,RunnableLambda(model))
    events=list(service.stream_answer(q['query'],q['id']+'-'+arm))
    elapsed=(time.perf_counter()-start)*1000
    assert captured == runner.read(root/'messages'/path.name)['messages'], path.name
    assert events[0]['sources'] == observed['sources'], path.name
    text=''.join(e.get('content','') for e in events)
    if arm=='new': assert history.messages[-1].content==text
    target=root/'answers'/path.name
    target.parent.mkdir(exist_ok=True)
    if text==previous['answer'] and events[0]['sources']==previous['sources']:
        shutil.copy2(prior/'answers'/path.name,target)
    else:
        citations=re.findall(r'\[([^\]\n]+)\]',text)
        record={**previous,'answer':text,'has_citations':bool(citations),
                'citation_ids_valid':all(c in {s['id'] for s in observed['sources']} for c in citations),
                'service_replay_ms':elapsed,'accepted_replay':True,
                'previous_record_sha256':runner.digest(prior/'answers'/path.name)}
        runner.write(target,record)
        changed.append(path.name)
runner.write(root/'replay-summary.json',{'records':600,'changed':changed,
    'unchanged':600-len(changed),'model_input_parity':600,'source_parity':600,
    'new_generation_calls':0})
print(json.dumps({'records':600,'changed':changed},ensure_ascii=False))
