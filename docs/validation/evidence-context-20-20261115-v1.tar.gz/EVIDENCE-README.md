# Complete-entry context: paired 20-question diagnostic

The package freezes questions, top-four candidates, old/new application code,
exact model messages, forty answers, both blinded judge rounds, and usage/timing.
Each judgment binds both answer hashes. `qualitative-review.json` records direct
answer inspection; raw automatic scores remain unchanged. Quote-parser formatting
recovery and failed attempts are recorded in `parser-amendment.json`.

## Offline aggregation

```bash
python summarize.py --output reproduced-summary.json
```

The output must equal `summary.json`. Only Python's standard library is needed.
The conditional source-stratified cluster interval describes these twenty selected
cases. The main pass is correct AND supported. Citation pass additionally requires
an actual valid bracketed marker. Direct review found shared judge errors on b215.

## Paid regeneration

Install the project's backend dependencies and set DASHSCOPE_API_KEY in the process
environment. Use a fresh copy without answers/judgments/judge_swapped checkpoints:

```bash
python runner.py validate
python runner.py answer
python resume_logged.py judge
python resume_logged.py audit
python summarize.py --output rerun-summary.json
```

Both arms have the same fixed system prompt, model configuration, frozen candidates
and separate empty histories. Only complete-entry recovery and reviewed exclusions
are enabled in the new arm. Runtime generation timing excludes retrieval and HTTP;
first application content is measured, model first-token callback was unavailable.
`inputs-manifest.json` binds original inputs; `artifact-manifest.json` binds all
packaged files. Model aliases and service responses can vary across reruns.
