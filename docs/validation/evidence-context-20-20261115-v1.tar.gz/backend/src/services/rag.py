"""Grounded robot customer-service answers over a managed internal corpus."""

import json
import logging
import re

from langchain_community.embeddings import DashScopeEmbeddings
from langchain_community.chat_models.tongyi import ChatTongyi
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables import RunnableLambda, RunnableWithMessageHistory

from src import config
from src.history import FileChatMessageHistory
from src.services.retrieval import InternalKnowledgeRetriever

from .prompts import SYSTEM_PROMPT
from .context import EvidenceContextBuilder

logger = logging.getLogger(__name__)


def internal_history(session_id):
    return FileChatMessageHistory(session_id, str(config.DATA_ROOT / "chat_history" / "robot_internal_v1"))


def source_items(documents):
    items = []
    for index, document in enumerate(documents, 1):
        item = {"id": f"S{index}", "filename": str(document.metadata.get("source", "内置资料")),
                "chunk_index": document.metadata.get("chunk_index", 0), "excerpt": document.page_content}
        digest = document.metadata.get("document_hash")
        spans = document.metadata.get("source_spans")
        if (isinstance(digest, str) and re.fullmatch(r"[0-9a-f]{64}", digest)
                and isinstance(spans, list) and spans
                and all(isinstance(span, dict)
                        and type(span.get("start_line")) is int and type(span.get("end_line")) is int
                        and 1 <= span["start_line"] <= span["end_line"] for span in spans)):
            item["document_hash"] = digest
            item["source_spans"] = [{"start_line": span["start_line"], "end_line": span["end_line"]}
                                    for span in spans]
        items.append(item)
    return items


def filter_citations(text, allowed):
    return re.sub(r"\[\s*((?:S)?\d[^\]\n]*)\]",
                  lambda match: f"[{match.group(1).strip()}]"
                  if match.group(1).strip() in allowed else "", text)


class RagService:
    def __init__(self, retriever=None, chat_model=None, history_factory=internal_history,
                 *, context_builder=None, context_entries_enabled=None):
        self.retriever = retriever if retriever is not None else InternalKnowledgeRetriever(
            DashScopeEmbeddings(model=config.embedding_model_name)
        )
        self.chat_model = chat_model if chat_model is not None else ChatTongyi(
            model=config.chat_model_name, max_retries=1,
            model_kwargs={"enable_thinking": False, "max_tokens": 1024},
        )
        self.context_entries_enabled = (config.context_entries_enabled if context_entries_enabled is None
                                        else context_entries_enabled)
        self.context_builder = context_builder if context_builder is not None else EvidenceContextBuilder()
        prompt = ChatPromptTemplate.from_messages([
            ("system", SYSTEM_PROMPT), MessagesPlaceholder("history"),
            ("human", "{request_payload}"),
        ])
        chain = RunnableLambda(lambda value: {
            "history": value.get("history", [])[-12:],
            "request_payload": json.dumps({
                "question": value["input"],
                "references": source_items(value["documents"]),
            }, ensure_ascii=False),
        }) | prompt | self.chat_model | StrOutputParser()
        self.chain = RunnableWithMessageHistory(
            chain, history_factory, input_messages_key="input", history_messages_key="history",
        )

    def stream_answer(self, query: str, session_id: str):
        risk_terms = ("鼓包", "冒烟", "烧焦", "起火", "漏电", "短接", "带电维修", "拆电池")
        if any(term in query for term in risk_terms):
            yield {"sources": []}
            yield {"content": "涉及电池、电气或起火风险，请停止使用和充电，在确保自身安全的前提下远离设备，联系专业售后；不要自行拆修或继续测试。"}
            return
        documents = self.retriever.invoke(query)
        if self.context_entries_enabled:
            context = self.context_builder.build(documents)
            documents = list(context.documents)
            logger.info("Evidence entries=%d reviews=%s fallback_count=%d",
                        context.entry_count, context.excluded_reviews, len(context.fallback_reasons))
        yield {"sources": source_items(documents)}
        if not documents:
            yield {"content": "当前内置知识库没有找到可用资料，无法据此确认。请补充型号或问题细节，必要时联系对应品牌售后。"}
            return
        allowed = {f"S{index}" for index in range(1, len(documents) + 1)}
        pending = ""
        for chunk in self.chain.stream(
            {"input": query, "documents": documents},
            config={"configurable": {"session_id": session_id}},
        ):
            if not chunk:
                continue
            pending += chunk
            # Keep an incomplete citation until its closing bracket arrives.
            opening = pending.rfind("[")
            boundary = opening if opening >= 0 and "]" not in pending[opening:] else len(pending)
            text, pending = pending[:boundary], pending[boundary:]
            cleaned = filter_citations(text, allowed)
            if cleaned:
                yield {"content": cleaned}
        if pending:
            cleaned = re.sub(r"\[\s*S?\d[^\]\n]*$", "", filter_citations(pending, allowed))
            if cleaned:
                yield {"content": cleaned}


class ChatUnavailable(Exception):
    """Safe public business error; HTTP mapping belongs to routes."""


class EmptyQuestion(Exception):
    pass


def prepare_question(text: str, knowledge: dict) -> str:
    if not config.model_configured():
        raise ChatUnavailable("模型待配置，请管理员配置 DashScope API Key 后启用服务")
    query = text.strip()
    if not query:
        raise EmptyQuestion("问题不能为空")
    if not knowledge["ready"]:
        raise ChatUnavailable("内置知识库尚未就绪，请管理员完成资料导入")
    return query
