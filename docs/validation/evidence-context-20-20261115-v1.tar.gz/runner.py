"""Isolated real-service prompt comparison; does not query or modify any database."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "backend"))
sys.path.insert(0, str(ROOT))


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def checked():
    for relative, expected in read(ROOT / "inputs-manifest.json").items():
        assert digest(ROOT / relative) == expected, relative
    data = read(ROOT / "dataset.json")
    protocol = read(ROOT / "protocol.json")
    assert digest(ROOT / "dataset.json") == protocol["dataset_sha256"]
    assert digest(ROOT / "corpus.json") == data["corpus_sha256"]
    return {q["id"]: q for q in data["questions"]}, protocol


def documents(question):
    from langchain_core.documents import Document
    rows = {d["id"]: d for d in read(ROOT / "corpus.json")}
    return [Document(id=key, page_content=rows[key]["content"], metadata=rows[key]["metadata"])
            for key in question["frozen_chunk_ids"]]


def build(question, arm, model):
    from langchain_core.chat_history import InMemoryChatMessageHistory
    module = importlib.import_module("bundles." + arm + ".rag")
    docs = documents(question)

    class FrozenRetriever:
        def invoke(self, query):
            assert query == question["query"]
            return docs

    history = InMemoryChatMessageHistory()
    options = {}
    if arm == "new":
        from bundles.new.context import EvidenceContextBuilder
        from bundles.new.corpus import load_internal_files
        options = {"context_entries_enabled": True,
                   "context_builder": EvidenceContextBuilder(lambda: load_internal_files(ROOT / "knowledge" / "robot"))}
    service = module.RagService(retriever=FrozenRetriever(), chat_model=model,
                                history_factory=lambda _: history, **options)
    return service, history


def serialize(messages):
    return [{"role": m.type, "content": m.content} for m in messages]


def validate():
    from langchain_core.runnables import RunnableLambda
    questions, protocol = checked()
    for q in questions.values():
        for arm in ("old", "new"):
            captured = []

            def capture(value):
                captured.extend(serialize(value.to_messages()))
                return "边界验证 [S1]"

            service, history = build(q, arm, RunnableLambda(capture))
            events = list(service.stream_answer(q["query"], "validation-" + q["id"] + arm))
            assert len(captured) == 2 and [m["role"] for m in captured] == ["system", "human"]
            refs = events[0]["sources"]
            assert len(refs) == 4 and [r["id"] for r in refs] == ["S1", "S2", "S3", "S4"]
            payload = json.loads(captured[1]["content"])
            assert payload == {"question": q["query"], "references": refs}
            assert all(r["excerpt"] not in captured[0]["content"] for r in refs)
            assert history.messages[0].content == q["query"] and len(history.messages) == 2
            path = ROOT / "messages" / f"{q['id']}-{arm}.json"
            record = {"id": q["id"], "arm": arm, "messages": captured, "sources": refs,
                      "dataset_sha256": protocol["dataset_sha256"]}
            if path.exists():
                assert read(path) == record
            else:
                write(path, record)
    new_systems = {read(ROOT / "messages" / f"{q['id']}-new.json")["messages"][0]["content"] for q in questions.values()}
    assert len(new_systems) == 1
    manifest = {p.name: digest(p) for p in sorted((ROOT / "messages").glob("*.json"))}
    if (ROOT / "messages-manifest.json").exists():
        assert read(ROOT / "messages-manifest.json") == manifest
    else:
        write(ROOT / "messages-manifest.json", manifest)
    print(json.dumps({"validated_messages": len(manifest), "each_arm_model_source_parity": True, "stable_new_system": True}), flush=True)


def answer():
    from langchain_community.chat_models.tongyi import ChatTongyi
    from langchain_core.callbacks import BaseCallbackHandler
    questions, protocol = checked()
    for name, expected in read(ROOT / "messages-manifest.json").items():
        assert digest(ROOT / "messages" / name) == expected

    class Trace(BaseCallbackHandler):
        raise_error = True

        def __init__(self, expected):
            self.expected = expected
            self.messages = None
            self.info = None
            self.first_model_token_ms = None
            self.start = time.perf_counter()

        def on_chat_model_start(self, serialized, messages, **kwargs):
            assert len(messages) == 1
            self.messages = serialize(messages[0])
            assert self.messages == self.expected

        def on_llm_new_token(self, token, **kwargs):
            if token and self.first_model_token_ms is None:
                self.first_model_token_ms = (time.perf_counter() - self.start) * 1000

        def on_llm_end(self, response, **kwargs):
            self.info = response.generations[0][0].generation_info

    total = 0
    for job in protocol["execution"]:
        q = questions[job["id"]]
        for arm in job["arms"]:
            path = ROOT / "answers" / f"{q['id']}-{arm}.json"
            if path.exists():
                assert read(path)["dataset_sha256"] == protocol["dataset_sha256"]
                total += 1
                continue
            message_record = read(ROOT / "messages" / f"{q['id']}-{arm}.json")
            tracker = Trace(message_record["messages"])
            llm = ChatTongyi(model="qwen-plus", max_retries=1, callbacks=[tracker],
                            model_kwargs={"enable_thinking": False, "max_tokens": 1024,
                                          "temperature": 0, "seed": 20261111})
            service, history = build(q, arm, llm)
            tracker.start = start = time.perf_counter()
            events = []
            first_content_ms = None
            try:
                for event in service.stream_answer(q["query"], q["id"] + "-" + arm):
                    if event.get("content") and first_content_ms is None:
                        first_content_ms = (time.perf_counter() - start) * 1000
                    events.append(event)
                elapsed = (time.perf_counter() - start) * 1000
                text = "".join(e.get("content", "") for e in events)
                assert text.strip() and tracker.messages == message_record["messages"]
                assert events[0]["sources"] == message_record["sources"]
                assert tracker.info and tracker.info["finish_reason"] == "stop", "missing_usage_or_incomplete"
                assert tracker.info["token_usage"].get("input_tokens", 0) > 0
                assert len(history.messages) == 2 and history.messages[0].content == q["query"]
                raw_citations = re.findall(r"\[([^\]\n]+)\]", text)
                valid = all(c in {"S1", "S2", "S3", "S4"} for c in raw_citations)
                write(path, {"id": q["id"], "arm": arm, "answer": text,
                             "chunk_ids": q["frozen_chunk_ids"], "sources": events[0]["sources"],
                             "elapsed_ms": elapsed, "first_content_ms": first_content_ms,
                             "first_model_token_ms": tracker.first_model_token_ms,
                             "generation_info": tracker.info,
                             "citation_ids_valid": valid, "has_citations": bool(raw_citations),
                             "message_sha256": digest(ROOT / "messages" / f"{q['id']}-{arm}.json"),
                             "dataset_sha256": protocol["dataset_sha256"],
                             "completed_at": datetime.now(timezone.utc).isoformat()})
            except Exception as error:
                failure = ROOT / "failures" / f"answer-{q['id']}-{arm}-{time.time_ns()}.json"
                write(failure, {"stage": "answer", "id": q["id"], "arm": arm,
                                "error_type": type(error).__name__,
                                "generation_info": tracker.info,
                                "elapsed_ms": (time.perf_counter() - start) * 1000})
                raise RuntimeError(f"answer_failed_{q['id']}_{arm}_{type(error).__name__}") from None
            total += 1
            print(json.dumps({"answered": total, "total": 40, "id": q["id"], "arm": arm,
                              "input_tokens": tracker.info["token_usage"]["input_tokens"],
                              "elapsed_ms": round(elapsed)}), flush=True)


def grade_call(system, payload):
    import httpx
    body = {"model": "qwen-max", "input": {"messages": [
        {"role": "system", "content": system},
        {"role": "user", "content": json.dumps(payload, ensure_ascii=False)}]},
        "parameters": {"result_format": "message", "enable_thinking": False,
                       "temperature": 0, "seed": 20261111, "max_tokens": 2200}}
    with httpx.Client(timeout=httpx.Timeout(90, connect=5), follow_redirects=False) as client:
        response = client.post("https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation",
                               headers={"Authorization": "Bearer " + os.environ["DASHSCOPE_API_KEY"]}, json=body)
    if response.status_code != 200:
        raise RuntimeError(f"judge_http_{response.status_code}")
    value = response.json()
    choice = value["output"]["choices"][0]
    assert choice["finish_reason"] == "stop", "judge_incomplete"
    text = choice["message"]["content"].strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    parsed = json.loads(text)
    assert type(parsed.get("reference_valid")) is bool
    for letter in ("A", "B"):
        assert all(type(parsed[letter].get(k)) is bool for k in (
            "correct", "supported", "context_sufficient", "citation_supported"))
    for letter in ("A", "B"):
        assert type(parsed[letter].get("unsafe_advice")) is bool
        assert isinstance(parsed[letter].get("unsafe_quote"), str)
        if parsed[letter]["unsafe_advice"]:
            assert parsed[letter]["unsafe_quote"] and parsed[letter]["unsafe_quote"] in payload[letter]["answer"]
            parsed[letter]["correct"] = False
    return parsed, value.get("usage", {}), value.get("request_id")


def judge(swapped):
    questions, protocol = checked()
    system = (ROOT / "judge_prompt.txt").read_text(encoding="utf-8")
    assert hashlib.sha256(system.encode()).hexdigest() == protocol["judging"]["prompt_sha256"]
    folder = "judge_swapped" if swapped else "judgments"
    for i, q in enumerate(questions.values(), 1):
        path = ROOT / folder / (q["id"] + ".json")
        if path.exists():
            assert read(path)["dataset_sha256"] == protocol["dataset_sha256"]
            continue
        order = protocol["judge_order"][q["id"]].copy()
        if swapped:
            order.reverse()
        payload = {"question": q["query"], "source_item": q["passage"],
                   "reference": q["reference"], "required_points": q["required_points"],
                   "safety_expected": q["safety_expected"]}
        answer_hashes = {}
        for letter, arm in zip(("A", "B"), order):
            source = ROOT / "answers" / f"{q['id']}-{arm}.json"
            answer_hashes[arm] = digest(source)
            record = read(source)
            payload[letter] = {"answer": record["answer"],
                               "context": "\n\n".join("[" + s["id"] + "] " + s["filename"] + "\n" + s["excerpt"]
                                                        for s in record["sources"])}
        start = time.perf_counter()
        for attempt in range(3):
            try:
                result, usage, request_id = grade_call(system, payload)
                break
            except Exception as error:
                write(ROOT / "failures" / f"{folder}-{q['id']}-{time.time_ns()}.json", {
                    "stage": folder, "id": q["id"], "error_type": type(error).__name__,
                    "attempt": attempt + 1})
                if attempt == 2:
                    raise RuntimeError(f"judge_failed_{q['id']}_{type(error).__name__}") from None
                time.sleep(1 + attempt)
        write(path, {"id": q["id"], "scores": {arm: result[letter] for letter, arm in zip(("A", "B"), order)},
                     "reference_valid": result["reference_valid"], "blinded_order": order,
                     "answer_sha256": answer_hashes, "usage": usage, "request_id": request_id,
                     "elapsed_ms": (time.perf_counter() - start) * 1000,
                     "dataset_sha256": protocol["dataset_sha256"]})
        print(json.dumps({"stage": folder, "completed": i, "total": 20, "id": q["id"]}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["validate", "answer", "judge", "audit"])
    args = parser.parse_args()
    if args.stage == "validate":
        validate()
    elif args.stage == "answer":
        answer()
    else:
        judge(args.stage == "audit")
