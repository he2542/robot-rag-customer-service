"""Recompute frozen pointwise judgments and model usage without network access."""
import hashlib
import json
from pathlib import Path
from decimal import Decimal

from paired_statistics import paired_binary

BASE=Path(__file__).resolve().parent
load=lambda p:json.loads((BASE/p).read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256((BASE/p).read_bytes()).hexdigest()
hash_value=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest()


def main():
    for name,expected in load('artifact-manifest.json').items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        assert sha(name)==expected,name
    for name,expected in load('inputs-manifest.json').items():assert sha(name)==expected,name
    assert sha('evaluation/postprocess_validation.py')==load('runner.json')['sha256']
    for folder,manifest in [('answers','answers-manifest.json'),('scores','scores-manifest.json'),('judgments','judgments-manifest.json')]:
        expected=load(manifest)
        assert {p.name:sha(p.relative_to(BASE)) for p in (BASE/folder).glob('*.json')}==expected
    data=load('prepared-dataset.json');protocol=load('protocol.json');judge=load('judge-prompt.json')['system']
    policies={}
    for version,file in [('pre','baseline_policy.py'),('post','candidate_policy.py')]:
        namespace={};exec(compile((BASE/file).read_bytes(),file,'exec'),namespace)
        policies[version]=namespace['render_context_answer']
    ids=set();rows=[]
    for q in data['questions']:
        assert q['id'] not in ids;ids.add(q['id'])
        a=load('answers/'+q['id']+'.json')
        assert a['frozen_sha256']==sha('inputs-manifest.json')
        row={'id':q['id'],'category':q['category'],'changed':a['answers']['pre']!=a['answers']['post']}
        for version in ['pre','post']:
            if not a['generation'].get('guarded'):
                assert policies[version](a['generation']['text'],a['sources'],q['query'])==a['answers'][version]
            j=load(f"judgments/{q['id']}-{version}.json")
            assert j['answer_sha256']==hash_value(a['answers'][version])
            s=load('scores/'+j['score_file'])
            payload={'question':q['query'],'required_points':q['required_points'],'references':a['sources'],'answer':a['answers'][version]}
            messages=[{'role':'system','content':judge},{'role':'user','content':json.dumps(payload,ensure_ascii=False)}]
            body={'model':protocol['judge'],'input':{'messages':messages},'parameters':{'result_format':'message','temperature':0,'seed':protocol['seed'],'enable_thinking':False,'max_tokens':512,'response_format':{'type':'json_object'}}}
            assert hash_value(body)==s['input_sha256']==s['response']['input_sha256']==Path(j['score_file']).stem
            verdict=json.loads(s['response']['text'])
            assert verdict==s['verdict'] and len(verdict['points'])==len(q['required_points'])
            assert all(type(v) is bool for v in verdict['points']+[verdict[k] for k in ['correct','supported','safe']])
            assert s['response']['finish_reason']=='stop'
            row[version]=all(verdict['points']) and all(verdict[k] for k in ['correct','supported','safe']) and a['generation']['finish_reason']=='stop'
        rows.append(row)
    assert len(rows)==50
    pairs=[{'before':r['pre'],'after':r['post'],'source':r['category'],'cluster':r['id']} for r in rows]
    result={'questions':50,'per_question':rows,'statistics':paired_binary(pairs,seed=protocol['seed']),
            'by_category':{kind:{'n':sum(r['category']==kind for r in rows),'pre_pass':sum(r['pre'] for r in rows if r['category']==kind),'post_pass':sum(r['post'] for r in rows if r['category']==kind)} for kind in sorted({r['category'] for r in rows})},
            'changed':[r['id'] for r in rows if r['changed']],
            'paid_generation_calls':sum(not load(p.relative_to(BASE))['generation'].get('guarded',False) for p in (BASE/'answers').glob('*.json')),
            'unique_scoring_calls':len(list((BASE/'scores').glob('*.json'))),
            'pre_pass':sum(r['pre'] for r in rows),'post_pass':sum(r['post'] for r in rows),
            'wins':[r['id'] for r in rows if r['post'] and not r['pre']], 'losses':[r['id'] for r in rows if r['pre'] and not r['post']]}
    assert result==load('primary-summary.json')
    request_ids=[];stage_usage=[]
    for stage,folder,key,rate_in,rate_out in [('generation','answers','generation','0.8','2'),('primary_judge','scores','response','2.4','9.6'),('verification_judge','verification/scores','response','2.4','9.6')]:
        calls=0;inputs=outputs=0
        for file in (BASE/folder).glob('*.json'):
            value=load(file.relative_to(BASE))[key]
            if value.get('guarded'):continue
            assert value['finish_reason']=='stop'
            request_ids.append(value['request_id']);calls+=1
            inputs+=value['usage']['input_tokens'];outputs+=value['usage']['output_tokens']
        cost=(Decimal(inputs)*Decimal(rate_in)+Decimal(outputs)*Decimal(rate_out))/1000000
        stage_usage.append({'stage':stage,'calls':calls,'input_tokens':inputs,'output_tokens':outputs,'estimated_original_price_cny':str(cost)})
    assert len(request_ids)==len(set(request_ids))==113
    assert stage_usage==load('usage-summary.json')['stages']
    verification=load('verification/summary.json')
    assert verification['changed_labels']==sum(r['primary_pass']!=r['repeat_pass'] for r in verification['rows'])==0
    for row in verification['rows']:
        score=load('verification/scores/'+row['score_file'])
        assert score['verdict']==row['repeat']==json.loads(score['response']['text'])
    print(json.dumps({'primary':result['statistics'],'verification_labels':len(verification['rows']),'verification_changes':verification['changed_labels'],'usage':load('usage-summary.json')},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
