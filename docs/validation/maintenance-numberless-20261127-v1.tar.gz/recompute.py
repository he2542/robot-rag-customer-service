import hashlib,json,socket,runpy
from pathlib import Path
base=Path(__file__).resolve().parent
for name,sha in json.loads((base/"manifest.json").read_text()).items():
    assert not Path(name).is_absolute() and ".." not in Path(name).parts
    assert hashlib.sha256((base/name).read_bytes()).hexdigest()==sha
socket.socket.connect=lambda *a,**k:(_ for _ in ()).throw(AssertionError("No network"))
old=runpy.run_path(str(base/"before_policy.py"))["render_context_answer"]
new=runpy.run_path(str(base/"after_policy.py"))["render_context_answer"]
rows=json.loads((base/"cases.json").read_text(encoding="utf-8"));summary=json.loads((base/"summary.json").read_text(encoding="utf-8"))
for r in rows:
    if not r["guarded"]:
        assert old(r["raw"],r["sources"],r["question"])==r["before"]
        assert new(r["raw"],r["sources"],r["question"])==r["after"]
    if r["before"]!=r["after"]:
        assert r["review"]["reversed_order_agrees"] and all(r["review"]["after_points"])
for group in ["codex20","qwen50"]:
    selected=[r for r in rows if r["group"]==group];s=summary[group]
    assert len(selected)==s["n"] and sum(r["before_pass"] for r in selected)==s["before_pass"] and sum(r["after_pass"] for r in selected)==s["after_pass"]
print(json.dumps({k:summary[k] for k in ["codex20","qwen50","new_model_calls"]}))
