import json,hashlib
from pathlib import Path
from codex_client import fingerprint,parse_events
from paired_statistics import paired_binary
base=Path(__file__).resolve().parent
def read(name):return json.loads((base/name).read_text(encoding="utf-8"))
for name,digest in read("manifest.json").items():
    assert not Path(name).is_absolute() and ".." not in Path(name).parts
    assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest,name
report=read("report.json");data=read("independent/inputs.json")
assert fingerprint(data)==read("independent/manifest.json")["inputs_sha256"]
frozen=read("codex/frozen-inputs.json");protocol=read("codex/codex-protocol.json")
assert fingerprint(frozen)==data["frozen_sha256"]==protocol["frozen_sha256"]
for stage in ["generate","judge"]:
    rows=list((base/"codex"/stage).glob("*.json"));assert len(rows)==20
    for p in rows:
        row=read(p.relative_to(base));assert Path(row["cache_file"]).name==row["cache_file"]
        result=read("codex/cache/"+row["cache_file"])
        assert fingerprint(result)==row["result_sha256"]
        assert fingerprint(result["binding"])+".json"==row["cache_file"]
        parsed=parse_events("\n".join(json.dumps(e) for e in result["events"]))
        assert parsed["text"]==result["text"] and parsed["usage"]==result["usage"]
        assert result["binding"]["identity"]==protocol["identity"]
rows=[]
def passed(v):
    assert all(type(x) is bool for x in v["points"]+[v["correct"],v["supported"],v["safe"]])
    return all(v["points"]) and all(v[k] for k in ["correct","supported","safe"])
for q in data["questions"]:
    score=read("independent/scores/"+q["id"]+".json")
    assert fingerprint(q["body"])==q["body_sha256"]==score["input_sha256"]==score["response"]["input_sha256"]
    assert score["response"]["finish_reason"]=="stop"
    v=json.loads(score["response"]["text"])
    rows.append({"before":passed(q["baseline_verdict"]) and q["baseline_finish"]=="stop","after":passed(v),"source":q["category"],"cluster":q["id"]})
assert len(rows)==20 and paired_binary(rows)==report["statistics"]
a=[x for name in ["ledgers/subscription-1.json","ledgers/subscription-2.json"] for x in read(name)["attempts"]]
assert len(a)==33 and sum(x["status"]=="failed" for x in a)==1
assert read("ledgers/qwen.json")["calls_reserved"]==13
print(json.dumps({"baseline_pass":sum(x["before"] for x in rows),"codex_pass":sum(x["after"] for x in rows),"n":20,"subscription_attempts":len(a),"qwen_calls":13}))
